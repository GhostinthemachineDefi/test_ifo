export { default } from './Whitepaper'
