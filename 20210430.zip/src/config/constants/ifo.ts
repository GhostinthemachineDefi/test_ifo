import farms from './farms'
import tokens from './tokens'
import { Ifo, Token } from './types'

const cakeBnbLpToken: Token = {
  symbol: farms[1].lpSymbol,
  address: farms[1].lpAddresses,
  decimals: 18,
}

const ifos: Ifo[] = [
  {
    id: 'gen',
    address: '0xf6487D7AdbE84061f1560c4CC613A98Ff2Da3AEF',
    isActive: true,
    name: 'test of Farming (GEN)',
    poolBasic: {
      saleAmount: '40,000 GEN',
      raiseAmount: '$750,000',
      cakeToBurn: '$375,000',
      distributionRatio: 0.5,
    },
    poolUnlimited: {
      saleAmount: '40,000 GEN',
      raiseAmount: '$1,750,000',
      cakeToBurn: '$875,000',
      distributionRatio: 0.5,
    },
    currency: cakeBnbLpToken,
    token: tokens.aof,
    releaseBlockNumber: 6988000,
    campaignId: '511090001',
    articleUrl: 'https://dragonballfinance.org/',
    tokenOfferingPrice: 0.25,
    isV1: false,
  }
]

export default ifos
